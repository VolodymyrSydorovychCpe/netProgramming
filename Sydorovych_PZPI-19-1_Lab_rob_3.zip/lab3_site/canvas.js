var c = document.getElementById("myCanvas");
var ctx = c.getContext("2d");

var grd = ctx.createLinearGradient(0, 0, 200, 0);
grd.addColorStop(0, "red");
grd.addColorStop(1, "white");

ctx.fillStyle = grd;
ctx.fillRect(0, 0, 200, 100);

ctx.moveTo(10, 10);
ctx.lineTo(40, 10);
ctx.stroke();

ctx.moveTo(10, 20);
ctx.lineTo(40, 20);
ctx.stroke();

ctx.moveTo(10, 30);
ctx.lineTo(40, 30);
ctx.stroke();

ctx.moveTo(10, 40);
ctx.lineTo(40, 40);
ctx.stroke();

ctx.beginPath();
ctx.arc(120, 50, 40, 0, 2 * Math.PI);
ctx.stroke();

ctx.font = "12px Arial";
ctx.strokeText("My country", 10, 80);