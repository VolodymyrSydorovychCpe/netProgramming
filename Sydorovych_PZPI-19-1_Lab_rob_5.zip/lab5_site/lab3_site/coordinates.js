if ("geolocation" in navigator) {
	navigator.geolocation.getCurrentPosition(function(position) {
			var coordinates = document.getElementById("coordinates");
			coordinates.textContent = "latitude: " + position.coords.latitude + " | " + "Longitude: " + position.coords.longitude;
	});
}

