var productCatalog = ['BMW', 'Mersedes', 'Audi', 'Citroen', 'Seat', 'Maseratti', 'VW', 'Chevrollet']

var form = document.forms.order;
var field = form.elements['field'];

field.addEventListener("change", 
			function(e){
				var foundBrands = []
				productCatalog.forEach(function(brand) {
					if (brand.toUpperCase().startsWith(field.value.toUpperCase())) {
						foundBrands.push(brand);
					}					
				});
				if (foundBrands.length === 1) {
					field.value = foundBrands[0];
				}
});
			
