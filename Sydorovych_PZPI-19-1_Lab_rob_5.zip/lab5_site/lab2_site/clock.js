var clock = document.getElementById("clock");

function time(){
    var d = new Date();
    var s = d.getSeconds();
    var m = d.getMinutes();
    var h = d.getHours();
	clock.textContent = h + ":" + m + ":" + s;
}

setInterval(time,1000);