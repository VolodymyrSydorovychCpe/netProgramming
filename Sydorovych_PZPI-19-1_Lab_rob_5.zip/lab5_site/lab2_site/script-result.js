var vehicalType = document.getElementById("vehical-type");
var brand = document.getElementById("brand");
var model = document.getElementById("model");
var complectation = document.getElementById("complectation");
var price = document.getElementById("price");

function getParameterByName(name, url) {
    if (!url) url = window.location.href;
    name = name.replace(/[\[\]]/g, '\\$&');
    var regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)'),
        results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, ' '));
}

var vehicalTypeData = getParameterByName('vehical-type');
var brandData = getParameterByName('brand');
var modelData = getParameterByName('model');
var complectationData = getParameterByName('complectation');
var priceData = getParameterByName('price');

vehicalType.textContent += vehicalTypeData;
brand.textContent += brandData;
model.textContent += modelData;
complectation.textContent += complectationData;
price.textContent += priceData;