var productCatalog = {
	'car' : {
		'BMW' : {
			'X5' : ['Base','Comfort','Busyness'],
			'X3' : ['Base','Comfort','M5'],
		},
		Mercedes : {
			'GLE' : ['AMG43', 'AMG63'],
			'GLA' : ['Base', 'AMG43'],
		},
		Citroen : {
			'C5 Aircross' : ['Feel', 'Shine'],
			'C3' : ['Feel', 'Shine'],
		},
		Nissan : {
			'X-Trail' : ['Base', 'Advanced'],
			'X-Trail' : ['Base', 'Advanced'],
		}
	},
	'bike' : {
		'BMW' : {
			'Sport-bike' : ['X1'],
		},
		'Kawasaki' : {
			'Winner' : ['Number1'],
		},		
	},
}

var form = document.forms.order;
var vehicalTypeSelect = form.elements['vehical-type'];
var brandSelect = form.elements['brand'];
var modelSelect = form.elements['model'];
var complectationSelect = form.elements['complectation'];

vehicalTypeSelect.addEventListener("change", 
			function(e){
				brandSelect.options.length = 0;
				modelSelect.options.length = 0;
				complectationSelect.options.length = 0;
				if(!vehicalTypeSelect.value) {
					return;
				}
				var keys = Object.keys(productCatalog[vehicalTypeSelect.value]);
				var defaultOption = document.createElement("option");
				brandSelect.add(defaultOption);
				keys.forEach(function(brand) {
					var option = document.createElement("option");
					option.text = brand;
					brandSelect.add(option);					
				});
			});
			
brandSelect.addEventListener("change", 
			function(e){
				modelSelect.options.length = 0;
				complectationSelect.options.length = 0;
				if(!brandSelect.value) {
					return;
				}
				var defaultOption = document.createElement("option");
				modelSelect.add(defaultOption);
				var keys = Object.keys(productCatalog[vehicalTypeSelect.value][brandSelect.value]);
				keys.forEach(function(model) {
					var option = document.createElement("option");
					option.text = model;
					modelSelect.add(option);					
				});
			});

modelSelect.addEventListener("change", 
			function(e){
				complectationSelect.options.length = 0;
				if(!modelSelect.value) {
					return;
				}
				var defaultOption = document.createElement("option");
				complectationSelect.add(defaultOption);
				var keys = productCatalog[vehicalTypeSelect.value][brandSelect.value][modelSelect.value];
				keys.forEach(function(complectation) {
					var option = document.createElement("option");
					option.text = complectation;
					complectationSelect.add(option);					
				});
			});


